import { app, BrowserWindow } from 'electron';
import { join } from 'path';
import { is } from '@electron-toolkit/utils'

let mainWindow; // Declare here

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 670,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });
  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    mainWindow.loadURL('http://localhost:5173/dashboard');
} else {
  mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
  }
}


app.disableHardwareAcceleration();
app.whenReady().then(createWindow);
