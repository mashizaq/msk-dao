import { contextBridge, ipcRenderer } from 'electron';
import Database from 'better-sqlite3';
import { ipcMain } from 'electron';
import path from 'path';

contextBridge.exposeInMainWorld('electronAPI', {
  fetchUsers: () => ipcRenderer.invoke('get-data')
});

const db = new Database(path.join(__dirname, 'mydata.db'));

// Listen for requests from the Renderer
ipcMain.handle('get-data', async (event, query) => {
  return db.prepare('SELECT * FROM users').all();
});
