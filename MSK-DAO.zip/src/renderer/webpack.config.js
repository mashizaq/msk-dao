const path = require('path');

module.exports = {
  resolve: {
    extensions: ['.js', '.jsx', '.json'],
    alias: {
      // This tells Webpack that "@" means "src/renderer/src"
      '@': path.resolve(__dirname, 'src/renderer/src'),
    },
  },
};
