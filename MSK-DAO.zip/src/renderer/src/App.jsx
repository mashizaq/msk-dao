import { useEffect, useState } from 'react';
import React from 'react';
import ReactDOM from 'react-dom/client';
import { useAccount } from 'wagmi';
import { QueryClient, QueryClientProvider, useQuery } from '@tanstack/react-query';
import { HashRouter as Router, Route, Routes } from 'react-router-dom';

import PageNotFound from './lib/PageNotFound';
import UserNotRegisteredError from './components/UserNotRegisteredError';
import AppLayout from './components/layout/AppLayout';
import Dashboard from './pages/Dashboard';
import Proposals from './pages/Proposals';
import Members from './pages/Members';
import Treasury from './pages/Treasury';
import Governance from './pages/Governance';
import Projects from './pages/Projects';
import DAOTransition from './pages/DAOTransition';
import MyProfile from './pages/MyProfile';

const queryClient = new QueryClient();

export function App() {
  const { isConnected, status } = useAccount();
  const [users, setUsers] = useState([]);

  // Fetch local SQLite data via Electron Bridge
  useEffect(() => {
    if (window.electronAPI) {
      window.electronAPI.fetchUsers().then(setUsers);
    }
  }, []);
  
  // Fetching members data via React Query
  const { data: members, isLoading: isLoadingPublicSettings } = useQuery({
    queryKey: ['members'],
    queryFn: () => window.api.getMembers()
  });

  const isLoadingAuth = false; 
  const authError = null; 

  // 1. Handle Loading States
  if (status === 'connecting' || isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
      </div>
    );
  }

  // 2. Handle Connection/Auth errors
  if (!isConnected) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Please connect your wallet to access the MSK DAO Desktop.</p>
      </div>
    );
  }

  if (authError?.type === 'user_not_registered') {
    return <UserNotRegisteredError />;
  }

  // 3. Main Application Routing
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/proposals" element={<Proposals />} />
        <Route path="/members" element={<Members />} />
        <Route path="/treasury" element={<Treasury />} />
        <Route path="/governance" element={<Governance />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/dao-transition" element={<DAOTransition />} />
        <Route path="/my-profile" element={<MyProfile />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}

// Ensure the root rendering is outside the component definition
const rootElement = document.getElementById('root');
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <QueryClientProvider client={queryClient}>
        <Router>
          <App />
        </Router>
      </QueryClientProvider>
    </React.StrictMode>
  );
}

export default App;
