// Using NASA for mission data and JSONPlaceholder for DAO entities
const SPACE_BASE_URL = "https://api.nasa.gov"; 
const DAO_BASE_URL = "https://jsonplaceholder.typicode.com"; 
const NASA_API_KEY = "DEMO_KEY"; // Free public key (30 requests/hr)

window.api = {
  auth: {
    // Simulates a connected state for the Mars Society Kenya DAO
    isConnected: async () => true, 
    // Returns a mock profile for a Mars Explorer
    me: async () => ({
      id: 1,
      name: "Kenyan Explorer",
      role: "Analog Astronaut",
      organization: "Mars Society Kenya"
    })
  },
  
  entities: new Proxy({}, {
    get: (target, entityName) => ({
      // Fetches real Mars data from NASA or mock DAO data
      filter: async (query = {}) => {
        let url;
        if (entityName === 'MarsPhotos') {
          url = `${SPACE_BASE_URL}/mars-photos/api/v1/rovers/curiosity/photos?sol=1000&api_key=${NASA_API_KEY}`;
        } else {
          // Maps DAO entities to generic mock endpoints (Proposals -> Posts)
          const endpointMap = { proposals: 'posts', members: 'users' };
          url = `${DAO_BASE_URL}/${endpointMap[entityName.toLowerCase()] || 'posts'}`;
        }
        
        const response = await fetch(url);
        return await response.json();
      },
      
      // Simulates fetching a specific DAO Proposal or Member
      get: async (id) => {
        const response = await fetch(`${DAO_BASE_URL}/posts/${id}`);
        return await response.json();
      },
      
      // Simulates creating a new Proposal (Stateless: won't persist on refresh)
      create: async (data) => {
        const response = await fetch(`${DAO_BASE_URL}/posts`, {
          method: 'POST',
          body: JSON.stringify(data),
          headers: { 'Content-type': 'application/json; charset=UTF-8' }
        });
        return await response.json();
      }
    })
  }),

  integrations: {
    Core: {
      // Free placeholder for file uploads
      UploadFile: async (file) => ({
        file_url: 'https://placeholder.com',
        status: 'mock_success'
      })
    }
  }
};
