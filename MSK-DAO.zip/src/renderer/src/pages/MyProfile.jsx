/* global globalThis */
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '../lib/AuthContext';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { User, Calendar, Mail, Pencil, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, parseISO } from 'date-fns';
import DuesStatusCard from '../components/profile/DuesStatusCard';
import VotingPowerCard from '../components/profile/VotingPowerCard';
import ContributionHistory from '../components/profile/ContributionHistory';
import MembershipPayment from '../components/members/MembershipPayment';
import ProposalAlerts from '../components/profile/ProposalAlerts';

// Global logic moved below imports
window.api = {
  auth: { isConnected: async () => false, me: async () => null },
  entities: new Proxy({}, { 
    get: () => ({ 
      filter: async () => [], 
      get: async () => null, 
      create: async () => ({}), 
      update: async () => ({}) 
    }) 
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
}; // <-- Ensure this closing brace and semicolon are here

const roleColors = {
  member:   'bg-secondary text-secondary-foreground',
  delegate: 'bg-accent/20 text-accent',
  council:  'bg-primary/20 text-primary',
  founder:  'bg-amber-500/20 text-amber-400',
};

export default function MyProfile() {
  const { user, logout } = useAuth();
  const [paymentOpen, setPaymentOpen] = useState(false);

  // Fetch this user's DAOMember record
  const { data: members = [] } = useQuery({
    queryKey: ['myMember', user?.email],
    queryFn: () => db.entities.DAOMember.filter({ email: user?.email }),
    enabled: !!user?.email,
  });
  const member = members[0] || null;

  // Fetch treasury transactions (filter client-side to those matching user email in description)
  const { data: allTransactions = [] } = useQuery({
    queryKey: ['transactions'],
    queryFn: () => db.entities.TreasuryTransaction.list('-created_date', 200),
  });
  const myTransactions = allTransactions.filter(t =>
    t.description?.toLowerCase().includes(user?.email?.toLowerCase()) ||
    t.created_by === user?.email
  );

  // Fetch proposals by this user
  const { data: allProposals = [] } = useQuery({
    queryKey: ['proposals'],
    queryFn: () => db.entities.Proposal.list('-created_date', 200),
  });
  const myProposals = allProposals.filter(p => p.author_email === user?.email);

  const initials = user?.full_name?.split(' ').map(n => n[0]).join('').toUpperCase() || '?';

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold">My Profile</h1>
          <p className="text-sm text-muted-foreground mt-1">Your DAO membership overview</p>
        </div>
        <Button variant="ghost" size="sm" onClick={() => logout()} className="text-muted-foreground gap-2">
          <LogOut className="w-4 h-4" /> Sign out
        </Button>
      </div>

      {/* Identity card */}
      <Card className="p-6 bg-card/50 border-border/50">
        <div className="flex items-start gap-5">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
            <span className="font-heading font-bold text-primary text-xl">{initials}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <h2 className="font-heading font-bold text-lg">{user?.full_name || 'Member'}</h2>
              {member?.role && (
                <Badge className={cn("text-xs", roleColors[member.role] || roleColors.member)}>
                  {member.role}
                </Badge>
              )}
              {member?.status && (
                <Badge className={cn(
                  "text-xs",
                  member.status === 'active'
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-destructive/20 text-destructive'
                )}>
                  {member.status}
                </Badge>
              )}
            </div>
            <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Mail className="w-3 h-3" /> {user?.email}
              </span>
              {member?.joined_date && (
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-3 h-3" />
                  Joined {format(parseISO(member.joined_date), 'dd MMM yyyy')}
                </span>
              )}
            </div>
            {member?.bio && (
              <p className="text-xs text-muted-foreground mt-2">{member.bio}</p>
            )}
            {member?.expertise?.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {member.expertise.map((e, i) => (
                  <Badge key={i} variant="outline" className="text-[10px] border-border/50">{e}</Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Stats row */}
      <div className="grid sm:grid-cols-2 gap-4">
        <DuesStatusCard transactions={myTransactions} onPayDues={() => setPaymentOpen(true)} />
        <VotingPowerCard member={member} />
      </div>

      {/* Vote alerts */}
      <ProposalAlerts userEmail={user?.email} />

      {/* Contribution history */}
      <ContributionHistory transactions={myTransactions} proposals={myProposals} />

      {!member && (
        <Card className="p-5 border-dashed border-border/50 bg-card/30 text-center">
          <p className="text-sm text-muted-foreground mb-3">
            No membership record found for <strong>{user?.email}</strong>.
          </p>
          <Button size="sm" onClick={() => setPaymentOpen(true)}>Pay Membership Dues to Register</Button>
        </Card>
      )}

      <MembershipPayment
        open={paymentOpen}
        onClose={() => setPaymentOpen(false)}
        preselectedMember={{ name: user?.full_name, email: user?.email }}
      />
    </div>
  );
}