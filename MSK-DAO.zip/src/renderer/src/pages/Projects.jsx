import React, { useState } from 'react';
import { Card } from '../components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ExternalLink, Tent, FlaskConical, BookOpen, Rocket, Globe, Users } from 'lucide-react';

const projects = [
  {
    id: 'camp-kipini',
    title: 'Camp Kipini',
    subtitle: 'Analog Astronaut Mission Site',
    icon: Tent,
    status: 'active',
    category: 'Research',
    description:
      'An analog mission environment in coastal Kenya used for astronaut training simulations, life-support testing, and Mars-analog research. Members can propose specific research tasks funded via DAO micro-grants.',
    tags: ['Analog Mission', 'Field Research', 'Astronaut Training'],
    url: 'https://kenyamarssociety.org/service/camp-kipini/',
    daoAction: 'Propose a micro-grant for Camp Kipini research',
  },
  {
    id: 'analog-habitat',
    title: 'Analog Habitat Research Centre',
    subtitle: 'Mars Surface Simulation Facility',
    icon: FlaskConical,
    status: 'active',
    category: 'Infrastructure',
    description:
      'A purpose-built research centre simulating Mars surface conditions — covering planning & architecture, habitat construction, furniture/equipment selection, and light/shadow studies for sealed environments.',
    tags: ['Habitat Design', 'ISRU Research', 'Life Support'],
    url: 'https://kenyamarssociety.org/portfolio-item/analog-habitat-research-centre/',
    daoAction: 'Vote on next habitat module',
  },
  {
    id: 'zindua-stem',
    title: 'Zindua STEM',
    subtitle: 'STEM Outreach & Education Program',
    icon: BookOpen,
    status: 'active',
    category: 'Education',
    description:
      'A nationwide STEM outreach program targeting Kenyan schools and universities. Includes university club chapters, an annual Inter-University Hackathon, and curriculum development for space sciences.',
    tags: ['STEM Education', 'University Clubs', 'Hackathon'],
    url: 'https://kenyamarssociety.org/portfolio-item/zindua-stem/',
    daoAction: 'Propose a school outreach event',
  },
  {
    id: 'space-city',
    title: 'Space City (Space Boot Camp)',
    subtitle: 'Immersive Space Training Academy',
    icon: Rocket,
    status: 'planning',
    category: 'Training',
    description:
      'An intensive residential boot camp providing STEM & space curriculum, Space Academy modules, and hands-on Space Training in a simulated mission environment. Designed to produce the next generation of African astronauts and engineers.',
    tags: ['Boot Camp', 'Space Academy', 'STEM Hub'],
    url: 'https://kenyamarssociety.org/portfolio-item/space-city/',
    daoAction: 'Vote on Space City curriculum',
  },
  {
    id: 'mars-society-chapters',
    title: 'University Chapters',
    subtitle: 'MSK Campus Network',
    icon: Globe,
    status: 'active',
    category: 'Community',
    description:
      'A growing network of Mars Society Kenya university clubs across Kenyan campuses. Chapters participate in the annual Inter-University Competition and gain reciprocal access to MSK resources and events.',
    tags: ['University Clubs', 'Competition', 'Networking'],
    url: 'https://kenyamarssociety.org',
    daoAction: 'Register your university chapter',
  },
  {
    id: 'afronaut',
    title: 'Afronaut Programme',
    subtitle: 'African Analog Astronaut Initiative',
    icon: Users,
    status: 'active',
    category: 'Research',
    description:
      'Led by Isaac Gathu (President, Analog Astronaut & Afronaut in Training), this programme develops African analog astronaut candidates through missions at Camp Kipini and international Mars Society analog research events.',
    tags: ['Analog Astronaut', 'Afronaut', 'International Collaboration'],
    url: 'https://kenyamarssociety.org',
    daoAction: 'Support the Afronaut Programme',
  },
];

const statusColors = {
  active: 'bg-emerald-500/20 text-emerald-400',
  planning: 'bg-amber-500/20 text-amber-400',
  proposed: 'bg-accent/20 text-accent',
};

const categoryColors = {
  Research: 'bg-primary/20 text-primary',
  Infrastructure: 'bg-blue-500/20 text-blue-400',
  Education: 'bg-purple-500/20 text-purple-400',
  Training: 'bg-orange-500/20 text-orange-400',
  Community: 'bg-teal-500/20 text-teal-400',
};

export default function Projects() {
  const [filter, setFilter] = useState('all');
  const categories = ['all', ...new Set(projects.map(p => p.category))];
  const filtered = filter === 'all' ? projects : projects.filter(p => p.category === filter);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold">Projects</h1>
          <p className="text-sm text-muted-foreground mt-1">
            MSK programs and initiatives — fund, vote, and propose via the DAO
          </p>
        </div>
        <a href="https://kenyamarssociety.org" target="_blank" rel="noopener noreferrer">
          <Button variant="outline" size="sm">
            <ExternalLink className="w-4 h-4 mr-1" /> kenyamarssociety.org
          </Button>
        </a>
      </div>

      {/* Category filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all border ${
              filter === cat
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-card/50 text-muted-foreground border-border/50 hover:border-primary/30'
            }`}
          >
            {cat === 'all' ? 'All Projects' : cat}
          </button>
        ))}
      </div>

      {/* Project Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map(project => {
          const Icon = project.icon;
          return (
            <Card
              key={project.id}
              className="p-5 bg-card/50 border-border/50 hover:border-primary/30 transition-all duration-300 flex flex-col"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div className="flex gap-1.5">
                  <Badge className={`text-[10px] px-2 ${statusColors[project.status] || ''}`}>
                    {project.status}
                  </Badge>
                  <Badge className={`text-[10px] px-2 ${categoryColors[project.category] || ''}`}>
                    {project.category}
                  </Badge>
                </div>
              </div>

              <h3 className="font-heading font-bold text-sm mb-0.5">{project.title}</h3>
              <p className="text-xs text-muted-foreground mb-3">{project.subtitle}</p>
              <p className="text-xs text-muted-foreground leading-relaxed flex-1">{project.description}</p>

              <div className="flex flex-wrap gap-1 mt-3 mb-4">
                {project.tags.map((tag, i) => (
                  <Badge key={i} variant="secondary" className="text-[10px] px-2">{tag}</Badge>
                ))}
              </div>

              <div className="flex gap-2 mt-auto">
                <a href={project.url} target="_blank" rel="noopener noreferrer" className="flex-1">
                  <Button variant="outline" size="sm" className="w-full text-xs">
                    <ExternalLink className="w-3 h-3 mr-1" /> Learn More
                  </Button>
                </a>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}