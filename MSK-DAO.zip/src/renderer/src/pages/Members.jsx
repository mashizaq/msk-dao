/* global globalThis */
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Search, ExternalLink, Users, CreditCard } from 'lucide-react';
import MemberCard from '../components/members/MemberCard';
import StatCard from '../components/dashboard/StatCard';
import MembershipPayment from '../components/members/MembershipPayment';
 
  window.api = {
  auth: { isConnected: async () => false, me: async () => null },
  entities: new Proxy({}, { 
    get: () => ({ 
      filter: async () => [], 
      get: async () => null, 
      create: async () => ({}), 
      update: async () => ({}) 
    }) 
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

export default function Members() {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [paymentOpen, setPaymentOpen] = useState(false);

  const { data: members = [], isLoading } = useQuery({
    queryKey: ['members'],
    queryFn: () => db.entities.DAOMember.list('-created_date', 200),
  });

  const filtered = members.filter(m => {
    const matchSearch = m.name?.toLowerCase().includes(search.toLowerCase()) ||
      m.email?.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === 'all' || m.role === roleFilter;
    return matchSearch && matchRole;
  });

  const activeCount = members.filter(m => m.status === 'active').length;
  const councilCount = members.filter(m => m.role === 'council' || m.role === 'founder').length;
  const totalVotingPower = members.reduce((acc, m) => acc + (m.voting_power || 1), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold">Members</h1>
          <p className="text-sm text-muted-foreground mt-1">DAO members and governance participants</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setPaymentOpen(true)}>
            <CreditCard className="w-4 h-4 mr-2" /> Pay Membership Dues
          </Button>
          <a href="https://kenyamarssociety.org/join/" target="_blank" rel="noopener noreferrer">
            <Button variant="outline">
              <ExternalLink className="w-4 h-4 mr-2" /> MSK Website
            </Button>
          </a>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <StatCard title="Active Members" value={activeCount} icon={Users} color="primary" />
        <StatCard title="Council Members" value={councilCount} icon={Users} color="accent" />
        <StatCard title="Total Voting Power" value={totalVotingPower} icon={Users} color="chart3" />
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search members..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Tabs value={roleFilter} onValueChange={setRoleFilter}>
          <TabsList className="bg-secondary/50">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="member">Members</TabsTrigger>
            <TabsTrigger value="delegate">Delegates</TabsTrigger>
            <TabsTrigger value="council">Council</TabsTrigger>
            <TabsTrigger value="founder">Founders</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <MembershipPayment open={paymentOpen} onClose={() => setPaymentOpen(false)} />

      {isLoading ? (
        <div className="grid sm:grid-cols-2 gap-4">
          {[1,2,3,4].map(i => (
            <div key={i} className="h-32 bg-card/50 rounded-lg animate-pulse border border-border/30" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-muted-foreground">No members found</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {filtered.map(m => <MemberCard key={m.id} member={m} />)}
        </div>
      )}
    </div>
  );
}