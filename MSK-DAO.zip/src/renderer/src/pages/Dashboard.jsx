/* global globalThis */
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Users, FileText, Wallet, Vote, ArrowRight, Rocket, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import StatCard from '../components/dashboard/StatCard';
import ProposalCard from '../components/proposals/ProposalCard';
import TransactionRow from '../components/treasury/TransactionRow';
 
  window.api = {
  auth: { isConnected: async () => false, me: async () => null },
  entities: new Proxy({}, { 
    get: () => ({ 
      filter: async () => [], 
      get: async () => null, 
      create: async () => ({}), 
      update: async () => ({}) 
    }) 
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

export default function Dashboard() {
  const { data: proposals = [] } = useQuery({
    queryKey: ['proposals'],
    queryFn: () => db.entities.Proposal.list('-created_date', 50),
  });

  const { data: members = [] } = useQuery({
    queryKey: ['members'],
    queryFn: () => db.entities.DAOMember.list('-created_date', 50),
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions'],
    queryFn: () => db.entities.TreasuryTransaction.list('-created_date', 10),
  });

  const activeProposals = proposals.filter(p => p.status === 'active');
  const passedProposals = proposals.filter(p => p.status === 'passed');
  const activeMembers = members.filter(m => m.status === 'active');

  const totalBalance = transactions.reduce((acc, t) => {
    if (t.type === 'deposit') return acc + (t.amount || 0);
    return acc - (t.amount || 0);
  }, 0);

  return (
    <div className="space-y-8">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 via-card to-accent/10 border border-border/50 p-8">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-accent/5 rounded-full blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
              <Rocket className="w-6 h-6 text-primary" />
            </div>
            <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">Autonomous DAO</Badge>
          </div>
          <h1 className="font-heading text-3xl md:text-4xl font-bold mb-2">Mars Society Kenya DAO</h1>
          <p className="text-muted-foreground max-w-xl text-sm leading-relaxed">
            Decentralized governance for Kenya's Mars exploration community — the Kenyan Chapter of the worldwide Mars Society under Dr. Robert Zubrin. 
            Propose, vote, and build the future of space exploration together. Humans to Mars within a decade.
          </p>
          <div className="flex gap-3 mt-6">
            <Link to="/proposals">
              <Button>
                <FileText className="w-4 h-4 mr-2" />View Proposals
              </Button>
            </Link>
            <a href="https://kenyamarssociety.org/join/" target="_blank" rel="noopener noreferrer">
              <Button variant="outline">
                <ExternalLink className="w-4 h-4 mr-2" />Become a Member
              </Button>
            </a>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Members" value={activeMembers.length} subtitle="Active members" icon={Users} color="accent" />
        <StatCard title="Active Proposals" value={activeProposals.length} subtitle={`${passedProposals.length} passed`} icon={Vote} color="primary" />
        <StatCard title="Total Proposals" value={proposals.length} icon={FileText} color="chart4" />
        <StatCard title="Treasury" value={`KES ${totalBalance.toLocaleString()}`} subtitle="Current balance" icon={Wallet} color="chart3" />
      </div>

      {/* Active Proposals + Recent Transactions */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-heading font-bold text-lg">Active Proposals</h2>
            <Link to="/proposals">
              <Button variant="ghost" size="sm" className="text-xs text-muted-foreground">
                View all <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </Link>
          </div>
          {activeProposals.length === 0 ? (
            <Card className="p-8 bg-card/50 border-border/50 text-center">
              <p className="text-muted-foreground text-sm">No active proposals</p>
            </Card>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {activeProposals.slice(0, 4).map(p => (
                <ProposalCard key={p.id} proposal={p} />
              ))}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-heading font-bold text-lg">Recent Activity</h2>
            <Link to="/treasury">
              <Button variant="ghost" size="sm" className="text-xs text-muted-foreground">
                View all <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </Link>
          </div>
          <Card className="p-4 bg-card/50 border-border/50">
            {transactions.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-4">No transactions yet</p>
            ) : (
              transactions.slice(0, 5).map(t => (
                <TransactionRow key={t.id} transaction={t} />
              ))
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}