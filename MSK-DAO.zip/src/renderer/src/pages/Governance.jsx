import React from 'react';
import { Card } from '@/components/ui/card';
// Change these:
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Shield, Vote, Users, Clock, Scale, FileText, ExternalLink, Rocket } from 'lucide-react';

const rules = [
  {
    icon: Vote,
    title: 'Voting Mechanism',
    description: 'One-member-one-vote with delegation. Council members and founders may have elevated voting power. Simple majority (51%) required for standard proposals.',
  },
  {
    icon: Clock,
    title: 'Voting Period',
    description: 'All proposals have a minimum 7-day voting period. Urgent proposals may be fast-tracked with council approval (48 hours).',
  },
  {
    icon: Users,
    title: 'Quorum Requirements',
    description: 'At least 30% of active members must participate for a vote to be valid. Governance changes require 60% super-majority.',
  },
  {
    icon: Scale,
    title: 'Proposal Categories',
    description: 'Funding, Governance, Membership, Project, Partnership, and Amendment proposals each have specific review processes.',
  },
  {
    icon: Shield,
    title: 'Council Oversight',
    description: 'The DAO Council (President, Secretary, Treasurer, Executive Director and Board Members) reviews proposals. Veto can be overridden by 75% member vote.',
  },
  {
    icon: FileText,
    title: 'Transparency & Privacy',
    description: 'All proposals, votes, and treasury transactions are visible to DAO members. Mars Society Kenya is committed to protecting your privacy per the MSK Privacy Policy.',
  },
];

const roles = [
  { role: 'Founder', power: 3, description: 'Isaac Gathu (President/Founder) — original founding member of Mars Society Kenya. An Analog Astronaut and Afronaut in Training.', badge: 'bg-amber-500/20 text-amber-400' },
  { role: 'Council', power: 2, description: 'Executive council: Secretary, Treasurer, Executive Director, and Board Members who oversee strategy and operations.', badge: 'bg-primary/20 text-primary' },
  { role: 'Delegate', power: 1.5, description: 'University club chapter leads and STEM coordinators with delegated voting power.', badge: 'bg-accent/20 text-accent' },
  { role: 'Member', power: 1, description: 'Standard DAO members: Student, Adult Single, Senior, Single Parent, Adult Couple, and Family membership tiers.', badge: 'bg-secondary text-secondary-foreground' },
];

export default function Governance() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-heading text-2xl font-bold">Governance</h1>
        <p className="text-sm text-muted-foreground mt-1">Rules, roles, and principles of the Mars Society Kenya DAO</p>
      </div>

      {/* Mission */}
      <Card className="p-6 bg-gradient-to-br from-primary/10 via-card to-accent/5 border-border/50">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
            <Rocket className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="font-heading font-bold text-lg mb-2">Our Mission</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Mars Society Kenya is a non-profit, youthful community of space enthusiasts — the Kenyan Chapter of the worldwide Mars Society under <strong className="text-foreground">Dr. Robert Zubrin</strong>. Our goal: to partner with the Kenyan government in reviving the space industry, and to elevate public awareness toward landing human explorers on Mars within a decade.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed mt-2">
              <strong className="text-foreground">Core Values:</strong> Safety &amp; Integrity · Teamwork · Excellence · Inclusion
            </p>
            <a href="https://kenyamarssociety.org" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-primary text-sm mt-3 hover:underline">
              <ExternalLink className="w-3.5 h-3.5" /> Visit kenyamarssociety.org
            </a>
          </div>
        </div>
      </Card>

      {/* Governance Rules */}
      <div>
        <h2 className="font-heading font-bold text-lg mb-4">Governance Rules</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rules.map((rule, i) => (
            <Card key={i} className="p-5 bg-card/50 border-border/50 hover:border-primary/30 transition-all">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <rule.icon className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-heading font-semibold text-sm mb-2">{rule.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{rule.description}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* Roles */}
      <div>
        <h2 className="font-heading font-bold text-lg mb-4">Member Roles & Voting Power</h2>
        <div className="space-y-3">
          {roles.map((r, i) => (
            <Card key={i} className="p-4 bg-card/50 border-border/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <Badge className={r.badge}>{r.role}</Badge>
                <p className="text-sm text-muted-foreground">{r.description}</p>
              </div>
              <div className="text-right">
                <span className="font-heading font-bold text-lg text-primary">{r.power}x</span>
                <p className="text-[10px] text-muted-foreground">voting power</p>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Join CTA */}
      <Card className="p-8 bg-card/50 border-border/50 text-center">
        <h2 className="font-heading font-bold text-xl mb-2">Join the DAO</h2>
        <p className="text-sm text-muted-foreground mb-2 max-w-lg mx-auto">
          Membership tiers: <strong className="text-foreground">Student</strong> (under 24) · <strong className="text-foreground">Adult Single</strong> (25–65) · <strong className="text-foreground">Senior</strong> (25+ continuous years, age 65+) · <strong className="text-foreground">Single Parent</strong> · <strong className="text-foreground">Adult Couple</strong> · <strong className="text-foreground">Family</strong>
        </p>
        <p className="text-xs text-muted-foreground mb-6 max-w-md mx-auto">
          Membership is confirmed after speaking with the Executive Director. Pending members cannot vote, propose new members, or access members-only events.
        </p>
        <a href="https://kenyamarssociety.org/join/" target="_blank" rel="noopener noreferrer">
          <Button size="lg">
            <ExternalLink className="w-4 h-4 mr-2" /> Join Mars Society Kenya
          </Button>
        </a>
      </Card>
    </div>
  );
}