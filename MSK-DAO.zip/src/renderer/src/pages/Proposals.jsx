/* global globalThis */
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus } from 'lucide-react';
import ProposalCard from '../components/proposals/ProposalCard';
import CreateProposalDialog from '../components/proposals/CreateProposalDialog';
import ProposalDetailDialog from '../components/proposals/ProposalDetailDialog';
import { toast } from 'sonner';

window.api = {
  auth: { isConnected: async () => false, me: async () => null },
  entities: new Proxy({}, { 
    get: () => ({ 
      filter: async () => [], 
      get: async () => null, 
      create: async () => ({}), 
      update: async () => ({}) 
    }) 
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

export default function Proposals() {

  const [filter, setFilter] = useState('all');
  const [showCreate, setShowCreate] = useState(false);
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [isVoting, setIsVoting] = useState(false);
  const queryClient = useQueryClient();

  const { data: proposals = [], isLoading } = useQuery({
    queryKey: ['proposals'],
    queryFn: () => db.entities.Proposal.list('-created_date', 100),
  });

  const [userEmail, setUserEmail] = useState('');
  React.useEffect(() => {
    db.auth.me().then(u => setUserEmail(u.email)).catch(() => {});
  }, []);

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.Proposal.create({ ...data, author_email: userEmail }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proposals'] });
      setShowCreate(false);
      toast.success('Proposal created successfully');
    },
  });

  const handleVote = async (proposalId, vote) => {
    setIsVoting(true);
    const proposal = proposals.find(p => p.id === proposalId);
    const updatedVoters = [...(proposal.voters || []), { email: userEmail, vote, timestamp: new Date().toISOString() }];
    const voteKey = vote === 'for' ? 'votes_for' : vote === 'against' ? 'votes_against' : 'votes_abstain';
    
    await db.entities.Proposal.update(proposalId, {
      [voteKey]: (proposal[voteKey] || 0) + 1,
      voters: updatedVoters,
    });

    queryClient.invalidateQueries({ queryKey: ['proposals'] });
    setSelectedProposal(prev => prev ? { ...prev, [voteKey]: (prev[voteKey] || 0) + 1, voters: updatedVoters } : null);
    setIsVoting(false);
    toast.success('Vote cast successfully');
  };

  const filtered = filter === 'all' ? proposals : proposals.filter(p => p.status === filter);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold">Proposals</h1>
          <p className="text-sm text-muted-foreground mt-1">Governance proposals for Mars Society Kenya</p>
        </div>
        <Button onClick={() => setShowCreate(true)}>
          <Plus className="w-4 h-4 mr-2" /> New Proposal
        </Button>
      </div>

      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList className="bg-secondary/50">
          <TabsTrigger value="all">All ({proposals.length})</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="passed">Passed</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
          <TabsTrigger value="executed">Executed</TabsTrigger>
        </TabsList>
      </Tabs>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1,2,3].map(i => (
            <div key={i} className="h-48 bg-card/50 rounded-lg animate-pulse border border-border/30" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-muted-foreground">No proposals found</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(p => (
            <ProposalCard key={p.id} proposal={p} onClick={setSelectedProposal} />
          ))}
        </div>
      )}

      <CreateProposalDialog
        open={showCreate}
        onOpenChange={setShowCreate}
        onSubmit={createMutation.mutate}
        isSubmitting={createMutation.isPending}
      />

      <ProposalDetailDialog
        proposal={selectedProposal}
        open={!!selectedProposal}
        onOpenChange={(open) => !open && setSelectedProposal(null)}
        onVote={handleVote}
        userEmail={userEmail}
        isVoting={isVoting}
      />
    </div>
  );
}