/* global globalThis */
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Wallet, ArrowDownRight, ArrowUpRight, Loader2 } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import StatCard from '../components/dashboard/StatCard';
import TransactionRow from '../components/treasury/TransactionRow';
import { toast } from 'sonner';
 
  window.api = {
  auth: { isConnected: async () => false, me: async () => null },
  entities: new Proxy({}, { 
    get: () => ({ 
      filter: async () => [], 
      get: async () => null, 
      create: async () => ({}), 
      update: async () => ({}) 
    }) 
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

const COLORS = ['hsl(15, 85%, 55%)', 'hsl(250, 60%, 55%)', 'hsl(170, 60%, 45%)', 'hsl(45, 90%, 55%)', 'hsl(330, 65%, 55%)'];

const categories = [
  'membership_dues', 'donation', 'grant', 'project_funding',
  'operations', 'events', 'education', 'outreach', 'other'
];

const transactions = [
  { 
    id: 1, 
    type: 'Inflow', 
    category: 'Grant', 
    amount: '5,000', 
    token: 'USDC', 
    status: 'Completed', 
    date: '2024-03-15' 
  }
];

export default function Treasury() {
  const [filter, setFilter] = useState('all');
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ type: 'deposit', amount: '', description: '', category: '' });
  const queryClient = useQueryClient();

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ['transactions'],
    queryFn: () => db.entities.TreasuryTransaction.list('-created_date', 200),
  });

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.TreasuryTransaction.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setShowAdd(false);
      setForm({ type: 'deposit', amount: '', description: '', category: '' });
      toast.success('Transaction recorded');
    },
  });

  const deposits = transactions.filter(t => t.type === 'deposit').reduce((s, t) => s + (t.amount || 0), 0);
  const withdrawals = transactions.filter(t => t.type !== 'deposit').reduce((s, t) => s + (t.amount || 0), 0);
  const balance = deposits - withdrawals;

  const categoryBreakdown = transactions
    .filter(t => t.type !== 'deposit')
    .reduce((acc, t) => {
      const cat = t.category || 'other';
      acc[cat] = (acc[cat] || 0) + (t.amount || 0);
      return acc;
    }, {});

  const pieData = Object.entries(categoryBreakdown).map(([name, value]) => ({
    name: name.replace(/_/g, ' '), value
  }));

  const filtered = filter === 'all' ? transactions : transactions.filter(t => t.type === filter);

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate({ ...form, amount: Number(form.amount) });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold">Treasury</h1>
          <p className="text-sm text-muted-foreground mt-1">DAO financial overview and transactions</p>
        </div>
        <Button onClick={() => setShowAdd(true)}>
          <Plus className="w-4 h-4 mr-2" /> Record Transaction
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <StatCard title="Balance" value={`KES ${balance.toLocaleString()}`} icon={Wallet} color="chart3" />
        <StatCard title="Total Deposits" value={`KES ${deposits.toLocaleString()}`} icon={ArrowDownRight} color="primary" />
        <StatCard title="Total Spent" value={`KES ${withdrawals.toLocaleString()}`} icon={ArrowUpRight} color="chart4" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Tabs value={filter} onValueChange={setFilter}>
            <TabsList className="bg-secondary/50">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="deposit">Deposits</TabsTrigger>
              <TabsTrigger value="withdrawal">Withdrawals</TabsTrigger>
              <TabsTrigger value="allocation">Allocations</TabsTrigger>
            </TabsList>
          </Tabs>
          <Card className="p-4 bg-card/50 border-border/50">
            {isLoading ? (
              <div className="space-y-3">
                {[1,2,3].map(i => <div key={i} className="h-12 bg-secondary/30 rounded animate-pulse" />)}
              </div>
            ) : filtered.length === 0 ? (
              <p className="text-center text-muted-foreground py-8 text-sm">No transactions</p>
            ) : (
              filtered.map(t => <TransactionRow key={t.id} transaction={t} />)
            )}
          </Card>
        </div>

        <div>
          <Card className="p-5 bg-card/50 border-border/50">
            <h3 className="font-heading font-semibold text-sm mb-4">Spending Breakdown</h3>
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                    {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: 'hsl(222, 44%, 9%)', border: '1px solid hsl(222, 30%, 18%)', borderRadius: '8px' }}
                    labelStyle={{ color: 'hsl(210, 40%, 96%)' }}
                    formatter={(value) => [`KES ${value.toLocaleString()}`, '']}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-center text-muted-foreground text-sm py-8">No spending data</p>
            )}
            <div className="space-y-2 mt-4">
              {pieData.map((d, i) => (
                <div key={d.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="capitalize text-muted-foreground">{d.name}</span>
                  </div>
                  <span className="font-medium">KES {d.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-heading">Record Transaction</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 mt-2">
            <div className="space-y-2">
              <Label>Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="deposit">Deposit</SelectItem>
                  <SelectItem value="withdrawal">Withdrawal</SelectItem>
                  <SelectItem value="allocation">Allocation</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Amount (KES)</Label>
              <Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} required />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>
                  {categories.map(c => (
                    <SelectItem key={c} value={c}>{c.replace(/_/g, ' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required />
            </div>
            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
              <Button type="submit" disabled={createMutation.isPending}>
                {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Record
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}