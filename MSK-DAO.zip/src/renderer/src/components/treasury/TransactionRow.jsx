import React from 'react';
import { format } from 'date-fns';
import { ArrowUpRight, ArrowDownLeft, Wallet } from 'lucide-react';
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

const typeConfig = {
  deposit: {
    icon: ArrowDownLeft,
    color: "text-green-500",
    bg: "bg-green-500/10",
    sign: "+"
  },
  withdrawal: {
    icon: ArrowUpRight,
    color: "text-red-500",
    bg: "bg-red-500/10",
    sign: "-"
  },
  transfer: {
    icon: Wallet,
    color: "text-blue-500",
    bg: "bg-blue-500/10",
    sign: ""
  }
};

const TransactionRow = ({ transaction }) => {
  const config = typeConfig[transaction.type?.toLowerCase()] || typeConfig.deposit;
  const Icon = config.icon;

  return (
    <div className="flex items-center justify-between py-3 border-b border-border/30 last:border-0">
      <div className="flex items-center gap-3">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", config.bg)}>
          <Icon className={cn("w-4 h-4", config.color)} />
        </div>
        <div>
          <p className="text-sm font-medium">{transaction.description || 'No Description'}</p>
          <div className="flex items-center gap-2 mt-0.5">
            <Badge variant="outline" className="text-[10px]">
              {transaction.category?.replace(/_/g, ' ') || 'General'}
            </Badge>
            <span className="text-[10px] text-muted-foreground">
              {transaction.created_date 
                ? format(new Date(transaction.created_date), 'MMM d, yyyy') 
                : 'Date unknown'}
            </span>
          </div>
        </div>
      </div>
      <span className={cn("font-heading font-semibold text-sm", config.color)}>
        {config.sign}KES {transaction.amount?.toLocaleString() || '0'}
      </span>
    </div>
  );
};

export default TransactionRow;
