/* global globalThis */
import React, { useEffect, useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Vote, ArrowRight, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow, parseISO, isPast } from 'date-fns';
import { cn } from '@/lib/utils';
import { useAuth } from '@/lib/AuthContext';

window.api = {
  auth: { isConnected: async() => false, me: async() => null },
  entities: new Proxy({}, { 
    get: () => ({ 
      filter: async() => [], 
      get: async() => null, 
      create: async() => ({}), 
      update: async() => ({}) 
    }) 
  }),
  integrations: { Core: { UploadFile: async() => ({ file_url: '' }) } }
};

export default function NotificationBell() {
  const { user } = useAuth();
  const [proposals, setProposals] = useState([]);
  const [open, setOpen] = useState(false);
  const [dismissed, setDismissed] = useState(() => {
    try { return JSON.parse(localStorage.getItem('dismissed_proposals') || '[]'); }
    catch { return []; }
  });
  const ref = useRef(null);

  useEffect(() => {
    if (!user?.email) return;
    db.entities.Proposal.filter({ status: 'active' }).then(setProposals).catch(() => {});

    const unsub = db.entities.Proposal.subscribe((event) => {
      if (event.type === 'create' && event.data?.status === 'active') {
        setProposals(prev => [event.data, ...prev.filter(p => p.id !== event.data.id)]);
      } else if (event.type === 'update') {
        setProposals(prev =>
          event.data?.status === 'active'
            ? prev.map(p => p.id === event.id ? event.data : p).concat(
                prev.find(p => p.id === event.id) ? [] : [event.data]
              )
            : prev.filter(p => p.id !== event.id)
        );
      } else if (event.type === 'delete') {
        setProposals(prev => prev.filter(p => p.id !== event.id));
      }
    });
    return unsub;
  }, [user?.email]);

  // Close on outside click
  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const dismiss = (id) => {
    const next = [...dismissed, id];
    setDismissed(next);
    localStorage.setItem('dismissed_proposals', JSON.stringify(next));
  };

  const pending = proposals.filter(p => {
    if (dismissed.includes(p.id)) return false;
    if (p.voters?.some(v => v.email === user?.email)) return false;
    if (p.voting_deadline && isPast(parseISO(p.voting_deadline))) return false;
    return true;
  });

  return (
    <div className="relative" ref={ref}>
      <Button
        variant="ghost"
        size="icon"
        className="relative h-9 w-9"
        onClick={() => setOpen(o => !o)}
      >
        <Bell className="w-4 h-4" />
        {pending.length > 0 && (
          <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center leading-none">
            {pending.length}
          </span>
        )}
      </Button>

      {open && (
        <div className="absolute right-0 top-11 w-80 bg-card border border-border/50 rounded-xl shadow-2xl z-50 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border/30">
            <span className="text-sm font-medium">Vote Alerts</span>
            {pending.length > 0 && (
              <Badge className="bg-primary/20 text-primary text-[10px]">{pending.length} pending</Badge>
            )}
          </div>

          <div className="max-h-80 overflow-y-auto">
            {pending.length === 0 ? (
              <div className="text-center py-8 text-sm text-muted-foreground">
                No pending votes — you're all caught up!
              </div>
            ) : (
              pending.map(p => (
                <div key={p.id} className="flex items-start gap-3 p-3 hover:bg-secondary/30 border-b border-border/20 last:border-0">
                  <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                    <Vote className="w-3.5 h-3.5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium line-clamp-2 leading-snug">{p.title}</p>
                    {p.voting_deadline && (
                      <p className={cn(
                        "text-[11px] mt-0.5",
                        parseISO(p.voting_deadline) - new Date() < 86400000 * 2
                          ? "text-amber-400" : "text-muted-foreground"
                      )}>
                        Closes {formatDistanceToNow(parseISO(p.voting_deadline), { addSuffix: true })}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Link to="/proposals" onClick={() => setOpen(false)}>
                      <Button size="sm" className="h-6 text-[11px] px-2 gap-1">
                        Vote <ArrowRight className="w-3 h-3" />
                      </Button>
                    </Link>
                    <Button
                      size="sm" variant="ghost"
                      className="h-6 w-6 p-0 text-muted-foreground"
                      onClick={() => dismiss(p.id)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="px-4 py-2.5 border-t border-border/30">
            <Link to="/my-profile" onClick={() => setOpen(false)}>
              <Button variant="ghost" size="sm" className="w-full text-xs text-muted-foreground h-7">
                View all alerts in My Profile
              </Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}