import React from 'react';
// Removed: import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
// Removed: import { Badge } from '@/components/ui/badge';
// Removed: import { cn } from '@/lib/utils';
import { 
  GitPullRequest, MessageSquare, Vote, Star, 
  ChevronRight, Calendar, ExternalLink 
} from 'lucide-react';

const typeIcons = {
  proposal: <GitPullRequest className="w-4 h-4 text-blue-500" />,
  comment: <MessageSquare className="w-4 h-4 text-slate-500" />,
  vote: <Vote className="w-4 h-4 text-purple-500" />,
  milestone: <Star className="w-4 h-4 text-amber-500" />,
};

export default function ContributionHistory({ contributions = [] }) {
  return (
    // Replaced <Card> with standard div
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
      <div className="p-6 border-b border-slate-100 dark:border-slate-800">
        <h2 className="text-lg font-bold text-slate-900 dark:text-white">Contribution History</h2>
      </div>
      
      <div className="p-6">
        <div className="space-y-6">
          {contributions.length === 0 ? (
            <p className="text-center py-8 text-slate-500 text-sm italic">No contributions found yet.</p>
          ) : (
            contributions.map((item, index) => (
              <div key={index} className="group relative flex gap-4 pb-6 last:pb-0">
                {/* Timeline Line */}
                {index !== contributions.length - 1 && (
                  <div className="absolute left-4 top-10 bottom-0 w-px bg-slate-100 dark:bg-slate-800" />
                )}
                
                {/* Icon Circle */}
                <div className="relative z-10 w-8 h-8 rounded-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center shrink-0">
                  {typeIcons[item.type] || <ChevronRight className="w-4 h-4 text-slate-400" />}
                </div>

                <div className="flex-1 min-w-0 pt-1">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {item.title}
                    </h4>
                    {/* Replaced <Badge> with standard span */}
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 capitalize">
                      {item.type}
                    </span>
                  </div>
                  
                  <p className="text-xs text-slate-500 line-clamp-2 mb-2">
                    {item.description}
                  </p>
                  
                  <div className="flex items-center gap-4 text-[10px] text-slate-400 uppercase tracking-wider font-medium">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {item.date}
                    </span>
                    {item.link && (
                      <a 
                        href={item.link} 
                        className="flex items-center gap-1 text-blue-500 hover:text-blue-600 transition-colors"
                      >
                        <ExternalLink className="w-3 h-3" /> View
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
