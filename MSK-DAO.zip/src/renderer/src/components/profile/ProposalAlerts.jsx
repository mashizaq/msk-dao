/* global globalThis */
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

// UI Components
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

// Icons
import { 
  Bell, Clock, CheckCircle2, AlertTriangle, 
  ArrowRight, BellOff, Vote 
} from 'lucide-react';

// Utilities
import { cn } from '@/lib/utils';
import { parseISO, isPast, formatDistanceToNow } from 'date-fns';

// Now place your db constant here
 { 
  entities: { 
    Proposal: { filter: async () => [] } 
  } 
};

export default function ProposalAlerts({ userEmail }) {
  const [proposals, setProposals] = useState([]);
  const [dismissed, setDismissed] = useState(() => {
    try { return JSON.parse(localStorage.getItem('dismissed_proposals') || '[]'); }
    catch { return []; }
  });

  // Initial load
  useEffect(() => {
    db.entities.Proposal.filter({ status: 'active' }).then(setProposals).catch(() => {});
  }, []);

  // Real-time subscription — fires whenever a proposal is created or updated
  useEffect(() => {
    const unsub = db.entities.Proposal.subscribe((event) => {
      if (event.type === 'create' && event.data?.status === 'active') {
        setProposals(prev => [event.data, ...prev.filter(p => p.id !== event.data.id)]);
      } else if (event.type === 'update') {
        setProposals(prev =>
          event.data?.status === 'active'
            ? prev.map(p => p.id === event.id ? event.data : p).concat(
                prev.find(p => p.id === event.id) ? [] : [event.data]
              )
            : prev.filter(p => p.id !== event.id)
        );
      } else if (event.type === 'delete') {
        setProposals(prev => prev.filter(p => p.id !== event.id));
      }
    });
    return unsub;
  }, []);

  const dismiss = (id) => {
    const next = [...dismissed, id];
    setDismissed(next);
    localStorage.setItem('dismissed_proposals', JSON.stringify(next));
  };

  // Proposals that are active, not expired, and user hasn't voted on
  const pending = proposals.filter(p => {
    if (dismissed.includes(p.id)) return false;
    const hasVoted = p.voters?.some(v => v.email === userEmail);
    if (hasVoted) return false;
    if (p.voting_deadline && isPast(parseISO(p.voting_deadline))) return false;
    return true;
  });

  const alreadyVoted = proposals.filter(p =>
    p.voters?.some(v => v.email === userEmail)
  );

  if (proposals.length === 0) return null;

  return (
    <Card className="p-5 bg-card/50 border-border/50">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-primary" />
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Vote Alerts
          </p>
          {pending.length > 0 && (
            <Badge className="bg-primary/20 text-primary text-[10px] px-2">{pending.length} pending</Badge>
          )}
        </div>
      </div>

      {pending.length === 0 ? (
        <div className="flex items-center gap-2 text-sm text-emerald-400 py-2">
          <CheckCircle2 className="w-4 h-4" />
          You're all caught up — no pending votes.
        </div>
      ) : (
        <div className="space-y-2 mb-4">
          {pending.map(p => (
            <div
              key={p.id}
              className="flex items-start justify-between gap-3 p-3 rounded-lg bg-primary/5 border border-primary/15 hover:border-primary/30 transition-colors"
            >
              <div className="flex items-start gap-3 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Vote className="w-4 h-4 text-primary" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium line-clamp-1">{p.title}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <Badge className="bg-secondary text-muted-foreground text-[10px] px-2">{p.category}</Badge>
                    {p.voting_deadline && (
                      <span className={cn(
                        "flex items-center gap-1 text-[11px]",
                        parseISO(p.voting_deadline) - new Date() < 86400000 * 2
                          ? "text-amber-400"
                          : "text-muted-foreground"
                      )}>
                        <Clock className="w-3 h-3" />
                        {formatDistanceToNow(parseISO(p.voting_deadline), { addSuffix: true })}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <Link to="/proposals">
                  <Button size="sm" className="h-7 text-xs px-3 gap-1">
                    Vote <ArrowRight className="w-3 h-3" />
                  </Button>
                </Link>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
                  onClick={() => dismiss(p.id)}
                  title="Dismiss"
                >
                  <BellOff className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {alreadyVoted.length > 0 && (
        <div>
          <p className="text-[11px] text-muted-foreground mb-1.5 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Already voted
          </p>
          <div className="space-y-1">
            {alreadyVoted.map(p => {
              const myVote = p.voters?.find(v => v.email === userEmail)?.vote;
              return (
                <div key={p.id} className="flex items-center justify-between text-xs text-muted-foreground px-1">
                  <span className="line-clamp-1 flex-1 mr-2">{p.title}</span>
                  <Badge className={cn(
                    "text-[10px] px-2 shrink-0",
                    myVote === 'for' ? 'bg-emerald-500/20 text-emerald-400' :
                    myVote === 'against' ? 'bg-destructive/20 text-destructive' :
                    'bg-secondary text-muted-foreground'
                  )}>
                    {myVote}
                  </Badge>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </Card>
  );
}