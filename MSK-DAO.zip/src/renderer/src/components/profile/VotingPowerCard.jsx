import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap, TrendingUp, Vote, FileText, ShieldCheck } from 'lucide-react';
import { cn } from '@/lib/utils';

const roleColors = {
  member:   { bg: 'bg-secondary',      text: 'text-secondary-foreground' },
  delegate: { bg: 'bg-accent/20',      text: 'text-accent' },
  council:  { bg: 'bg-primary/20',     text: 'text-primary' },
  founder:  { bg: 'bg-amber-500/20',   text: 'text-amber-400' },
};

const roleMultiplier = { member: 1, delegate: 2, council: 3, founder: 5 };
const roleDesc = {
  member:   'Standard voting rights on all proposals',
  delegate: 'Delegated voting rights + can represent others',
  council:  'Enhanced governance powers + proposal veto',
  founder:  'Founding member — highest governance authority',
};

export default function VotingPowerCard({ member }) {
  if (!member) return null;

  const power = member.voting_power ?? roleMultiplier[member.role] ?? 1;
  const role = member.role || 'member';
  const colors = roleColors[role] || roleColors.member;
  const maxPower = 5;
  const fillPct = Math.min((power / maxPower) * 100, 100);

  return (
    <Card className="p-5 bg-card/50 border-border/50">
      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">
        Voting Power &amp; Role
      </p>

      <div className="flex items-center gap-3 mb-4">
        <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
          <span className="font-heading font-bold text-primary text-xl">{power}</span>
        </div>
        <div>
          <Badge className={cn("text-xs mb-1", colors.bg, colors.text)}>{role}</Badge>
          <p className="text-xs text-muted-foreground leading-snug">{roleDesc[role]}</p>
        </div>
      </div>

      {/* power bar */}
      <div className="mb-4">
        <div className="flex justify-between text-xs text-muted-foreground mb-1">
          <span>Voting weight</span>
          <span>{power} / {maxPower}</span>
        </div>
        <div className="h-2 rounded-full bg-secondary/60 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-all duration-700"
            style={{ width: `${fillPct}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-secondary/30 rounded-lg p-3 text-center">
          <Vote className="w-4 h-4 text-muted-foreground mx-auto mb-1" />
          <p className="font-heading font-bold text-sm">{member.votes_cast ?? 0}</p>
          <p className="text-[10px] text-muted-foreground">Votes Cast</p>
        </div>
        <div className="bg-secondary/30 rounded-lg p-3 text-center">
          <FileText className="w-4 h-4 text-muted-foreground mx-auto mb-1" />
          <p className="font-heading font-bold text-sm">{member.proposals_created ?? 0}</p>
          <p className="text-[10px] text-muted-foreground">Proposals</p>
        </div>
      </div>
    </Card>
  );
}