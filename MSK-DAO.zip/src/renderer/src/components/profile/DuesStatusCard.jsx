import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle2, AlertCircle, Clock, CreditCard } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, parseISO, addYears, isBefore } from 'date-fns';

export default function DuesStatusCard({ transactions = [], onPayDues }) {
  // Find most recent membership dues payment
  const duesPayments = transactions
    .filter(t => t.category === 'membership_dues' && t.type === 'deposit')
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  const lastPayment = duesPayments[0] || null;
  const lastPaidDate = lastPayment ? parseISO(lastPayment.created_date) : null;
  const renewalDate = lastPaidDate ? addYears(lastPaidDate, 1) : null;
  const isActive = renewalDate ? isBefore(new Date(), renewalDate) : false;
  const daysUntilRenewal = renewalDate
    ? Math.ceil((renewalDate - new Date()) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <Card className="p-5 bg-card/50 border-border/50">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
            Membership Status
          </p>
          {isActive ? (
            <>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span className="font-heading font-bold text-emerald-400">Active</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Renews {format(renewalDate, 'dd MMM yyyy')}
                {daysUntilRenewal <= 30 && (
                  <span className="text-amber-400 ml-1">({daysUntilRenewal}d left)</span>
                )}
              </p>
            </>
          ) : lastPayment ? (
            <>
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-destructive" />
                <span className="font-heading font-bold text-destructive">Expired</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Expired {format(renewalDate, 'dd MMM yyyy')}
              </p>
            </>
          ) : (
            <>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-muted-foreground" />
                <span className="font-heading font-bold text-muted-foreground">No record</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">No dues payment found</p>
            </>
          )}
        </div>
        <div className="text-right">
          {lastPayment && (
            <div className="mb-3">
              <p className="text-xs text-muted-foreground">Last paid</p>
              <p className="font-heading font-bold text-primary">
                KES {lastPayment.amount?.toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">{format(lastPaidDate, 'dd MMM yyyy')}</p>
            </div>
          )}
          <Button size="sm" onClick={onPayDues} className="gap-2">
            <CreditCard className="w-3 h-3" />
            {isActive ? 'Renew Early' : 'Pay Dues'}
          </Button>
        </div>
      </div>

      {duesPayments.length > 0 && (
        <div className="mt-4 pt-4 border-t border-border/30">
          <p className="text-xs text-muted-foreground mb-2">Payment history</p>
          <div className="space-y-1.5">
            {duesPayments.slice(0, 3).map((t, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">
                  {format(parseISO(t.created_date), 'dd MMM yyyy')}
                </span>
                <span className="font-medium text-emerald-400">
                  +KES {t.amount?.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}