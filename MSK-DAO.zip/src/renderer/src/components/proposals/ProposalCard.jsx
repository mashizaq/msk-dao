import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, CheckCircle2, XCircle, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const statusConfig = {
  draft: { label: 'Draft', color: 'bg-muted text-muted-foreground', icon: FileText },
  active: { label: 'Active', color: 'bg-primary/20 text-primary', icon: Clock },
  passed: { label: 'Passed', color: 'bg-emerald-500/20 text-emerald-400', icon: CheckCircle2 },
  rejected: { label: 'Rejected', color: 'bg-destructive/20 text-destructive', icon: XCircle },
  executed: { label: 'Executed', color: 'bg-accent/20 text-accent', icon: CheckCircle2 },
};

const categoryColors = {
  funding: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  governance: 'bg-accent/10 text-accent border-accent/20',
  membership: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  project: 'bg-primary/10 text-primary border-primary/20',
  partnership: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
  amendment: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
};

export default function ProposalCard({ proposal, onClick }) {
  const status = statusConfig[proposal.status] || statusConfig.draft;
  const totalVotes = (proposal.votes_for || 0) + (proposal.votes_against || 0) + (proposal.votes_abstain || 0);
  const forPercent = totalVotes > 0 ? ((proposal.votes_for || 0) / totalVotes) * 100 : 0;
  const StatusIcon = status.icon;

  return (
    <Card
      className="p-5 bg-card/50 backdrop-blur border-border/50 hover:border-primary/30 cursor-pointer transition-all duration-300 group"
      onClick={() => onClick?.(proposal)}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className={cn("text-[10px] border", categoryColors[proposal.category])}>
            {proposal.category}
          </Badge>
          <Badge className={cn("text-[10px]", status.color)}>
            <StatusIcon className="w-3 h-3 mr-1" />
            {status.label}
          </Badge>
        </div>
        {proposal.requested_amount > 0 && (
          <span className="text-xs font-medium text-amber-400">
            KES {proposal.requested_amount?.toLocaleString()}
          </span>
        )}
      </div>

      <h3 className="font-heading font-semibold text-foreground group-hover:text-primary transition-colors mb-2">
        {proposal.title}
      </h3>
      <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{proposal.description}</p>

      <div className="space-y-2">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>For: {proposal.votes_for || 0}</span>
          <span>Against: {proposal.votes_against || 0}</span>
        </div>
        <Progress value={forPercent} className="h-1.5" />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{totalVotes} total votes</span>
          {proposal.voting_deadline && (
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {format(new Date(proposal.voting_deadline), 'MMM d, yyyy')}
            </span>
          )}
        </div>
      </div>
    </Card>
  );
}