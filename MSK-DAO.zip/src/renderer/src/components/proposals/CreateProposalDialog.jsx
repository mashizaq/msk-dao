import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

const categories = [
  { value: 'funding', label: 'Funding Request' },
  { value: 'governance', label: 'Governance Change' },
  { value: 'membership', label: 'Membership' },
  { value: 'project', label: 'New Project' },
  { value: 'partnership', label: 'Partnership' },
  { value: 'amendment', label: 'Amendment' },
];

export default function CreateProposalDialog({ open, onOpenChange, onSubmit, isSubmitting }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    category: '',
    requested_amount: '',
    voting_deadline: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...form,
      requested_amount: form.requested_amount ? Number(form.requested_amount) : 0,
      status: 'active',
      votes_for: 0,
      votes_against: 0,
      votes_abstain: 0,
      quorum_required: 51,
      voters: [],
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl">Create New Proposal</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="space-y-2">
            <Label>Title</Label>
            <Input
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Proposal title"
              required
            />
          </div>
          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })} required>
              <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
              <SelectContent>
                {categories.map(c => (
                  <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Describe your proposal in detail..."
              rows={4}
              required
            />
          </div>
          {form.category === 'funding' && (
            <div className="space-y-2">
              <Label>Requested Amount (KES)</Label>
              <Input
                type="number"
                value={form.requested_amount}
                onChange={(e) => setForm({ ...form, requested_amount: e.target.value })}
                placeholder="0"
              />
            </div>
          )}
          <div className="space-y-2">
            <Label>Voting Deadline</Label>
            <Input
              type="datetime-local"
              value={form.voting_deadline}
              onChange={(e) => setForm({ ...form, voting_deadline: e.target.value })}
              required
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Submit Proposal
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}