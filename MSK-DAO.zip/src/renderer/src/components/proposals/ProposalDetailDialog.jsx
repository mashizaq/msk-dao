import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ThumbsUp, ThumbsDown, Minus, Clock, User } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const statusColors = {
  draft: 'bg-muted text-muted-foreground',
  active: 'bg-primary/20 text-primary',
  passed: 'bg-emerald-500/20 text-emerald-400',
  rejected: 'bg-destructive/20 text-destructive',
  executed: 'bg-accent/20 text-accent',
};

export default function ProposalDetailDialog({ proposal, open, onOpenChange, onVote, userEmail, isVoting }) {
  if (!proposal) return null;

  const totalVotes = (proposal.votes_for || 0) + (proposal.votes_against || 0) + (proposal.votes_abstain || 0);
  const forPercent = totalVotes > 0 ? ((proposal.votes_for || 0) / totalVotes) * 100 : 0;
  const againstPercent = totalVotes > 0 ? ((proposal.votes_against || 0) / totalVotes) * 100 : 0;
  
  const hasVoted = proposal.voters?.some(v => v.email === userEmail);
  const userVote = proposal.voters?.find(v => v.email === userEmail)?.vote;
  const isActive = proposal.status === 'active';
  const isExpired = proposal.voting_deadline && new Date(proposal.voting_deadline) < new Date();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2 mb-2">
            <Badge className={cn("text-xs", statusColors[proposal.status])}>
              {proposal.status}
            </Badge>
            <Badge variant="outline" className="text-xs">{proposal.category}</Badge>
          </div>
          <DialogTitle className="font-heading text-2xl">{proposal.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <User className="w-3.5 h-3.5" />
              {proposal.author_name || proposal.created_by}
            </span>
            {proposal.voting_deadline && (
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                Deadline: {format(new Date(proposal.voting_deadline), 'PPp')}
              </span>
            )}
          </div>

          <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">
            {proposal.description}
          </p>

          {proposal.requested_amount > 0 && (
            <div className="bg-secondary/50 rounded-lg p-4 border border-border/50">
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Requested Amount</p>
              <p className="text-2xl font-heading font-bold text-amber-400">
                KES {proposal.requested_amount?.toLocaleString()}
              </p>
            </div>
          )}

          <div className="space-y-3">
            <h4 className="font-heading font-semibold text-sm">Voting Results</h4>
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-emerald-500/10 rounded-lg p-3 text-center border border-emerald-500/20">
                <p className="text-2xl font-bold text-emerald-400">{proposal.votes_for || 0}</p>
                <p className="text-xs text-emerald-400/70">For</p>
              </div>
              <div className="bg-destructive/10 rounded-lg p-3 text-center border border-destructive/20">
                <p className="text-2xl font-bold text-destructive">{proposal.votes_against || 0}</p>
                <p className="text-xs text-destructive/70">Against</p>
              </div>
              <div className="bg-muted rounded-lg p-3 text-center border border-border">
                <p className="text-2xl font-bold text-muted-foreground">{proposal.votes_abstain || 0}</p>
                <p className="text-xs text-muted-foreground/70">Abstain</p>
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>For {forPercent.toFixed(0)}%</span>
                <span>Against {againstPercent.toFixed(0)}%</span>
              </div>
              <Progress value={forPercent} className="h-2" />
            </div>
          </div>

          {isActive && !isExpired && (
            <div className="border-t border-border pt-4">
              {hasVoted ? (
                <p className="text-sm text-muted-foreground text-center">
                  You voted <span className="font-semibold text-foreground">{userVote}</span> on this proposal
                </p>
              ) : (
                <div className="space-y-3">
                  <h4 className="font-heading font-semibold text-sm">Cast Your Vote</h4>
                  <div className="flex gap-3">
                    <Button
                      onClick={() => onVote(proposal.id, 'for')}
                      disabled={isVoting}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                    >
                      <ThumbsUp className="w-4 h-4 mr-2" /> For
                    </Button>
                    <Button
                      onClick={() => onVote(proposal.id, 'against')}
                      disabled={isVoting}
                      variant="destructive"
                      className="flex-1"
                    >
                      <ThumbsDown className="w-4 h-4 mr-2" /> Against
                    </Button>
                    <Button
                      onClick={() => onVote(proposal.id, 'abstain')}
                      disabled={isVoting}
                      variant="outline"
                      className="flex-1"
                    >
                      <Minus className="w-4 h-4 mr-2" /> Abstain
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}

          {isExpired && isActive && (
            <p className="text-center text-sm text-amber-400">Voting period has ended</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}