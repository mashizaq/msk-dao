import React from 'react';
// Imports for Shadcn (Card, Badge, cn) have been removed
import { User, Vote, FileText } from 'lucide-react';

const roleColors = {
  member: 'bg-slate-200 text-slate-800', // Using standard Tailwind colors
  delegate: 'bg-blue-100 text-blue-700',
  council: 'bg-purple-100 text-purple-700',
  founder: 'bg-amber-100 text-amber-700',
};

export default function MemberCard({ member }) {
  const initials = member.name?.split(' ').map(n => n[0]).join('').toUpperCase() || '?';

  return (
    // Replaced <Card> with a <div> and standard Tailwind border/bg classes
    <div className="p-5 bg-white/50 dark:bg-slate-900/50 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-xl hover:border-blue-500/30 transition-all duration-300 shadow-sm">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center shrink-0">
          <span className="font-bold text-blue-600 text-sm">{initials}</span>
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold text-sm truncate text-slate-900 dark:text-white">{member.name}</h3>
            
            {/* Replaced <Badge> with a <span> */}
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${roleColors[member.role] || 'bg-slate-100 text-slate-600'}`}>
              {member.role}
            </span>
          </div>
          
          <p className="text-xs text-slate-500 truncate">{member.email}</p>
          
          {member.bio && (
            <p className="text-xs text-slate-500 mt-2 line-clamp-2">{member.bio}</p>
          )}
          
          <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <Vote className="w-3 h-3" /> {member.votes_cast || 0} votes
            </span>
            <span className="flex items-center gap-1">
              <FileText className="w-3 h-3" /> {member.proposals_created || 0} props
            </span>
            <span className="flex items-center gap-1">
              <User className="w-3 h-3" /> Power: {member.voting_power || 1}
            </span>
          </div>

          {member.expertise?.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {member.expertise.map((e, i) => (
                <span key={i} className="px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 text-[10px] text-slate-500">
                  {e}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
