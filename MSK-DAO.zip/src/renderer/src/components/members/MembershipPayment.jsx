/* global globalThis */
import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { CheckCircle2, Loader2, AlertCircle, ArrowRight, Wallet, X } from 'lucide-react';

// 1. Fixed array syntax
 { /* mock config */ };
const MEMBERSHIP_TIERS = [ 
  { id: 'senior', label: 'Senior', price: 1000, desc: '...', badge: '...' }
];

export default function MembershipPayment({ open, onClose, preselectedMember = null }) {
  const queryClient = useQueryClient();
  const [step, setStep] = useState('select');
  const [tier, setTier] = useState(null);
  const [phone, setPhone] = useState('');
  const [name, setName] = useState(preselectedMember?.name || '');
  const [email, setEmail] = useState(preselectedMember?.email || '');
  const [error, setError] = useState('');

  // 2. Fixed Mutation syntax and logic
  const mutation = useMutation({
    mutationFn: async (data) => {

const IntaSend = require('intasend-node');

let intasend = new IntaSend(
    '<INTASEND_PUBLISHABLE_KEY>',
    '<INTASEND_SECRET_KEY>',
    true, // Test ? Set true for test environment
);

let collection = intasend.collection();
collection
   .mpesaStkPush({
  		first_name: 'Joe',
    	last_name: 'Doe',
    	email: 'joe@doe.com',
    	host: 'https://yourwebsite.com',
  		amount: 10,
    	phone_number: '254722000000',
    	api_ref: 'test',
  })
  .then((resp) => {
  	// Redirect user to URL to complete payment
  	 console.log(`STK Push Resp:`,resp);
	})
  .catch((err) => {
     console.error(`STK Push Resp error:`,err);
  });
      console.log("Processing payment for:", data);
      return data; 
    },
    onSuccess: () => { 
      setStep('success'); 
      queryClient.invalidateQueries(['members']); // Optional: refresh member list
    },
    onError: (err) => { 
      setError(err.message); 
    }
  });

  if (!open) return null;

  // Placeholder logic for the buttons
  const handleClose = () => {
    setStep('select');
    onClose();
  };

  return (
    <div className="payment-modal">
      {error && <p className="text-red-500">{error}</p>}
      
      {step === 'success' ? (
        <div>
          <CheckCircle2 />
          <p>Payment Successful!</p>
          <button onClick={handleClose}>Close</button>
        </div>
      ) : (
        <button 
          disabled={mutation.isPending}
          onClick={() => mutation.mutate({ tier, phone, name, email })}
        >
          {mutation.isPending ? <Loader2 className="animate-spin" /> : 'Pay Now'}
        </button>
      )}
    </div>
  );
}
