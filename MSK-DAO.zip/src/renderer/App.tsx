import { Toaster } from "./src/components/ui/toaster.jsx";
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClientInstance } from "./src/lib/query-client";
import { HashRouter as Router, Route, Routes } from "react-router-dom";
import PageNotFound from "./src/lib/PageNotFound";
import { AuthProvider, useAuth } from "./src/lib/AuthContext";
import UserNotRegisteredError from "./src/components/UserNotRegisteredError";
import AppLayout from "./src/components/layout/AppLayout";

// FIXED: Changed from "./src/" to "../" to correctly reach the root style files
import "../App.css";
import "../index.css";

// FIXED: Standardized paths to read correctly from your "./src/" layout
import Dashboard from "./src/pages/Dashboard.jsx";
import Proposals from "./src/pages/Proposals";
import Members from "./src/pages/Members";
import Treasury from "./src/pages/Treasury";
import Governance from "./src/pages/Governance";
import Projects from "./src/pages/Projects";
import DAOTransition from "./src/pages/DAOTransition";
import MyProfile from "./src/pages/MyProfile";

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/proposals" element={<Proposals />} />
        <Route path="/members" element={<Members />} />
        <Route path="/treasury" element={<Treasury />} />
        <Route path="/governance" element={<Governance />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/dao-transition" element={<DAOTransition />} />
        <Route path="/my-profile" element={<MyProfile />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;
