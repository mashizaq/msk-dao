import { join } from 'path'
import { defineConfig, externalizeDepsPlugin } from 'electron-vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  main: { /* ... */ },
  preload: { /* ... */ },
  renderer: {
    resolve: {
      alias: {
        '@': join(__dirname, 'src/renderer/src') // This fixes the @/ error
      }
    },
    plugins: [react()]
  }
})
